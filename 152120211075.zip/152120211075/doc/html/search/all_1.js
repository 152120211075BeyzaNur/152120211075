var searchData=
[
  ['averagefunction_0',['AverageFunction',['../152120211075_8cpp.html#a23789842ed5819e66a00dffb9385e1e6',1,'152120211075.cpp']]]
];
