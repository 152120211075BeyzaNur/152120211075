#include <iostream>
#include <fstream> 
#include <algorithm> 

int SumFunction(const int numbers[], int count) {
    int sum = 0;
    for (int i = 0; i < count; ++i) {         //! toplam fonksiyonu
        sum += numbers[i];
    }
    return sum;
}
int ProductFunction(const int numbers[], int count) {
    int product = 1;
    for (int i = 0; i < count; ++i) {          //! carpim fonksiyonu
        product *= numbers[i];
    }
    return product;
}
int SmallestFunction(const int numbers[], int count) {
    int smallest = numbers[0];
    for (int i = 0; i < count; ++i) {                     //! en kucuk deger
        smallest = std::min(smallest, numbers[i]);
    }
    return smallest;
}
int AverageFunction(const int numbers[], int count) {
    if (count == 0) {
        return 0; // Hesaplama hatasi �nlemek icin.
    }

    int sum = SumFunction(numbers, count);
    return sum / count;
}
int main() {
    const int Max_Size = 100; //! dizinin tasmasini �nlemek icin

    std::ifstream inputFile("input.txt"); //! dosyayi okumak icin nesne 

    if (!inputFile.is_open()) {
        std::cerr << "Unable to open input file." << std::endl; //! Hata mesaji yazdirir eger dosya bulunamazsa.
        return 1;
    }


    int count;
    inputFile >> count;     //! dosyanin ilk satirdan sayi okumasi. 


    if (count > Max_Size) {
        std::cerr << "Count exceeds the maximum size." << std::endl; //! Dizi boyutunu kontrol eder.
        return 1;
    }


    int numbers[Max_Size]{};
    for (int i = 0; i < count; ++i) { //! dosyadan okutulan degerler numbers dizisinde saklansin.
        inputFile >> numbers[i];
    }


    inputFile.close();             //! dosyayi kapatiyor.


    int sum = SumFunction(numbers, count);
    int product = ProductFunction(numbers, count);
    int smallest = SmallestFunction(numbers, count);
    int average = AverageFunction(numbers, count);


    std::cout << "Sum: " << sum << std::endl;     //! sonuclari ekrana yazdir.
    std::cout << "Product: " << product << std::endl;
    std::cout << "Average: " << average << std::endl;
    std::cout << "Smallest: " << smallest << std::endl;

    return 0;
}
